﻿namespace Exam
{
    public class ExamOrderProduct
    {
        public int OrderID { get; set; }
        public string ProductArticleNumber { get; set; }
        public int Amount { get; set; }
    }
}
