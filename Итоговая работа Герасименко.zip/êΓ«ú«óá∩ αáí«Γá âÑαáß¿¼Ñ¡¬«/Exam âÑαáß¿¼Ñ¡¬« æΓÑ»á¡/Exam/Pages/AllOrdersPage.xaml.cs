﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace Exam.Pages
{
    /// <summary>
    /// Логика взаимодействия для AllOrdersPage.xaml
    /// </summary>
    public partial class AllOrdersPage : Page
    {
        public static List<ExamOrder> examOrders = new();

        public double MinDiscount { get; set; } = 0;

        public double MaxDiscount { get; set; } = 100;

        public string SortMethod { get; set; } = "";
        public AllOrdersPage()
        {
            InitializeComponent();
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            GetOrderList(SortMethod, MinDiscount, MaxDiscount);
            CurrentUserLabel.Content = $"{CurrentUser.UserName.Substring(0, 1)}.{CurrentUser.UserPatronymic.Substring(0, 1)}. {CurrentUser.UserSurname}";
        }

        private void GetOrderList(string sortMethod, double minDiscount, double maxDiscount)//метод для вывода ысех существующих заказов на странцу
        {
            AllOrdersStackPanel.Children.Clear();
            examOrders = DataAccessLayer.GetExamOrdersDataFromDB(sortMethod, minDiscount, maxDiscount);
            int productsCount = examOrders.Count;
            for (int i = 0; i < productsCount; i++)//в цикле создаются отдельные элементы в которых хранятся данные о заказах
            {
                List<ExamOrderProduct> examOrderProducts = DataAccessLayer.GetOrderProductWithOrderId(examOrders[i].OrderID);//список товаров в заказе

                Border orderBorder = new();
                orderBorder.Width = 600;
                orderBorder.Margin = new Thickness(80, 5, 0, 5);
                orderBorder.BorderBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFCC6600"));
                orderBorder.BorderThickness = new(3);

                StackPanel orderPanel = new();
                orderPanel.Background = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#FFFFCC99"));

                DockPanel statusPanel = new();
                Label orderIdLabel = new();
                orderIdLabel.Content = $"Заказ №{examOrders[i].OrderID}";
                Label orderStatus = new();
                DockPanel.SetDock(orderStatus, Dock.Right);
                orderStatus.Content = examOrders[i].OrderStatus;
                statusPanel.Children.Add(orderStatus);
                statusPanel.Children.Add(orderIdLabel);
                orderPanel.Children.Add(statusPanel);

                StackPanel orderCompositionPanel = new();
                orderCompositionPanel.Orientation = Orientation.Horizontal;
                Label orderCompositionLabel = new();
                string orderComposition = "";
                for (int j = 0; j < examOrderProducts.Count; j++)
                {
                    orderComposition += $"\n{DataAccessLayer.GetProductNameWithArticle(examOrderProducts[j].ProductArticleNumber)}" +
                        $"({DataAccessLayer.GetProductAmountInOrderWithArticle(examOrders[i].OrderID, examOrderProducts[j].ProductArticleNumber)})";
                }
                examOrders[i].ProductsInOrder = $"Состав заказа:{orderComposition}";
                orderCompositionLabel.Content = examOrders[i].ProductsInOrder;
                orderCompositionPanel.Children.Add(orderCompositionLabel);
                orderPanel.Children.Add(orderCompositionPanel);

                Label orderSumLabel = new();
                decimal orderSum = DataAccessLayer.GetSummOrder(examOrders[i].OrderID);
                orderSumLabel.Content = $"Сумма заказа: " + orderSum.ToString("F2");
                orderPanel.Children.Add(orderSumLabel);

                Label orderDiscountLabel = new();
                decimal orderDiscount = DataAccessLayer.GetDiscountOrder(examOrders[i].OrderID);
                orderDiscountLabel.Content = $"Сумма скидки в заказе: " + orderDiscount.ToString("F2");
                orderPanel.Children.Add(orderDiscountLabel);

                if (examOrders[i].UserID != 0)
                {
                    Label orderPickupPointLabel = new();
                    orderPickupPointLabel.Content = $"ФИО клиента: {DataAccessLayer.GetUserFullNameWithOrderId(examOrders[i].OrderID)}";
                    orderPanel.Children.Add(orderPickupPointLabel);
                }

                Label orderDateLabel = new();
                orderDateLabel.Content = $"Дата: {examOrders[i].OrderDate}";
                orderPanel.Children.Add(orderDateLabel);

                StackPanel DeliveryStackPanel = new();
                DeliveryStackPanel.Orientation = Orientation.Horizontal;
                Label orderDeliveryDateLabel = new();
                orderDeliveryDateLabel.Content = $"Дата доставки:\n{examOrders[i].OrderDeliveryDate}";
                StackPanel ChangeDeliveryDateStackPanel = new();
                Label changeDeliveryDateLabel = new();
                changeDeliveryDateLabel.Content = "Изменить дату доставки:";
                TextBox changeDeliveryDateTextBox = new();
                changeDeliveryDateTextBox.Name = "changeTextBox";
                Button changeButton = new();
                changeButton.Tag = examOrders[i].OrderID;
                changeButton.Content = "Изменить";
                changeButton.Click += ChangeButton_Click;
                StackPanel StatusStackPanel = new();
                Label changeStatusLabel = new();
                changeStatusLabel.Content = "Статус:";
                ComboBox changeStatusComboBox = new();
                changeStatusComboBox.Tag = examOrders[i].OrderID;
                changeStatusComboBox.Items.Add("Новый");
                changeStatusComboBox.Items.Add("Завершен");
                changeStatusComboBox.SelectionChanged += ChangeStatusComboBox_SelectionChanged;
                StatusStackPanel.Children.Add(changeStatusLabel);
                StatusStackPanel.Children.Add(changeStatusComboBox);
                ChangeDeliveryDateStackPanel.Children.Add(changeDeliveryDateLabel);
                ChangeDeliveryDateStackPanel.Children.Add(changeDeliveryDateTextBox);
                ChangeDeliveryDateStackPanel.Children.Add(changeButton);
                DeliveryStackPanel.Children.Add(orderDeliveryDateLabel);
                DeliveryStackPanel.Children.Add(ChangeDeliveryDateStackPanel);
                DeliveryStackPanel.Children.Add(StatusStackPanel);
                orderPanel.Children.Add(DeliveryStackPanel);

                orderBorder.Child = orderPanel;
                AllOrdersStackPanel.Children.Add(orderBorder);
                searchedOrdersCount.Content = examOrders.Count.ToString() + " из " + DataAccessLayer.GetExamOrderCount();
            }
        }

        private void ChangeStatusComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)//изменение статуса заказа
        {
            ComboBox comboBox = sender as ComboBox;
            if (comboBox.SelectedIndex == 0)
                DataAccessLayer.UpdateExamOrderStatus("Новый", Convert.ToInt32(comboBox.Tag));
            else
                DataAccessLayer.UpdateExamOrderStatus("Завершен", Convert.ToInt32(comboBox.Tag));
            GetOrderList(SortMethod, MinDiscount, MaxDiscount);
        }

        private void ChangeButton_Click(object sender, RoutedEventArgs e)//изменение даты доставки заказа
        {
            Button changeButton = sender as Button;
            StackPanel stackPanel = changeButton.Parent as StackPanel;
            TextBox newDeliveryDateTextBox = stackPanel.Children.OfType<TextBox>().FirstOrDefault(tb => tb.Name == "changeTextBox");
            try
            {
                DataAccessLayer.UpdateExamOrderDeliveryDate(Convert.ToDateTime(newDeliveryDateTextBox.Text), Convert.ToInt32(changeButton.Tag));
            }
            catch
            {
                MessageBox.Show("Введен некорректный формат даты");
            }
            GetOrderList(SortMethod, MinDiscount, MaxDiscount);
        }

        private void Filter_SelectionChanged(object sender, SelectionChangedEventArgs e)//изменение условий вывода заказов с помощью фильтра
        {
            if (SortComboBox.SelectedIndex == 0)
                SortMethod = "ORDER BY SUM(ProductCost*(100-ProductDiscountAmount)/100*ExamOrderProduct.Amount) ASC";
            else SortMethod = "ORDER BY SUM(ProductCost*(100-ProductDiscountAmount)/100*ExamOrderProduct.Amount) DESC";

            if (DiscountFilterComboBox.SelectedIndex == 0)
            {
                MinDiscount = 0;
                MaxDiscount = 10;
            }

            if (DiscountFilterComboBox.SelectedIndex == 1)
            {
                MinDiscount = 10;
                MaxDiscount = 15;
            }

            if (DiscountFilterComboBox.SelectedIndex == 2)
            {
                MinDiscount = 15;
                MaxDiscount = 100;
            }

            if (DiscountFilterComboBox.SelectedIndex == 3)
            {
                MinDiscount = 0;
                MaxDiscount = 100;
            }

            GetOrderList(SortMethod, MinDiscount, MaxDiscount);//обновление списка заказов с фильтрацией
        }
        private void FilterOff_Click(object sender, RoutedEventArgs e)//сброс фильтрации и сортировки
        {
            SortComboBox.SelectedIndex = -1;
            DiscountFilterComboBox.SelectedIndex = -1;
            SortMethod = "";
            MinDiscount = 0;
            MaxDiscount = 100;
            GetOrderList(SortMethod, MinDiscount, MaxDiscount);//обновление списка товаров без фильтрации
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentFrame.GoBack();
        }
    }
}
