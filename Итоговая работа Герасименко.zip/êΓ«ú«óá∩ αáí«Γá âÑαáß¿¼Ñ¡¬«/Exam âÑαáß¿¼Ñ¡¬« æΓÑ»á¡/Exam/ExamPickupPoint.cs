﻿namespace Exam
{
    public class ExamPickupPoint
    {
        public int OrderPickupPoint { get; set; }
        public string Address { get; set; }
    }
}
