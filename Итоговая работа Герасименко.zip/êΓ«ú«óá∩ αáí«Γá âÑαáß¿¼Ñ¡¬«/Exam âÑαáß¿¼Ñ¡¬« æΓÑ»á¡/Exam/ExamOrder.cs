﻿namespace Exam
{
    public class ExamOrder
    {
        public int OrderID { get; set; }
        public int UserID { get; set; }
        public string OrderStatus { get; set; }
        public DateOnly OrderDate { get; set; }
        public DateOnly OrderDeliveryDate { get; set; }
        public int OrderPickupPoint { get; set; }
        public int OrderPickupCode { get; set; }
        public string ProductsInOrder { get; set; }
    }
}
