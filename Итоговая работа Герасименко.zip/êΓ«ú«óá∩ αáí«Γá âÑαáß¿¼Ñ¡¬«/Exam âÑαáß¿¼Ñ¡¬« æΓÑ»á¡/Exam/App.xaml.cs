﻿using System.Windows;
using System.Windows.Controls;

namespace Exam
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static Frame CurrentFrame { get; set; }
    }

}
